# signlanguageproject > 2024-08-26 9:47am
https://universe.roboflow.com/objectdetection-twsk1/signlanguageproject-lajoy

Provided by a Roboflow user
License: CC BY 4.0

